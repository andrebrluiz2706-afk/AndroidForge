package com.pimbol.assistant

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.IBinder
import android.os.Build
import android.view.View
import android.view.WindowManager
import kotlin.math.cos
import kotlin.math.sin

class AimOverlayService : Service() {
    companion object { const val ACTION_UPDATE = "com.pimbol.assistant.UPDATE_AIM" }
    private lateinit var wm: WindowManager
    private var aimView: AimView? = null
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { aimView?.invalidate() }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, IntentFilter(ACTION_UPDATE), RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, IntentFilter(ACTION_UPDATE))
        }
        val view = AimView(this)
        aimView = view
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        wm.addView(view, params)
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) { }
        aimView?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        aimView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private class AimView(context: Context) : View(context) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(90, 255, 120); strokeWidth = 5f; style = Paint.Style.STROKE }
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x665CFF78; strokeWidth = 15f; style = Paint.Style.STROKE }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 220, 70); style = Paint.Style.FILL }
        private val prefs = context.getSharedPreferences("aim", Context.MODE_PRIVATE)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height * 0.62f
            val angle = Math.toRadians(prefs.getFloat("angle", 0f).toDouble())
            val length = prefs.getInt("length", 420).toFloat()
            val dx = (cos(angle) * length).toFloat()
            val dy = (sin(angle) * length).toFloat()
            val ex = cx + dx
            val ey = cy + dy
            canvas.drawLine(cx, cy, ex, ey, glow)
            canvas.drawLine(cx, cy, ex, ey, line)
            canvas.drawCircle(cx, cy, 11f, dot)
            canvas.drawCircle(ex, ey, 13f, dot)
            canvas.drawCircle(cx, cy, 22f, line)
        }
    }
}
