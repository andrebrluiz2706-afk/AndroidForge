package com.pimbol.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("aim", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 91, 56)
        window.navigationBarColor = Color.rgb(8, 60, 39)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 28, 24, 28)
            setBackgroundColor(Color.rgb(12, 91, 56))
        }
        val title = TextView(this).apply {
            text = "🎱  PIMBOL"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "MIRA AUXILIAR • VERSÃO DE TESTE"
            textSize = 13f
            setTextColor(Color.rgb(211, 245, 218))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(label("Ajuste a direção da linha"))
        val angles = LinearLayout(this).apply { gravity = Gravity.CENTER }
        angles.addView(button("↶ 5°") { adjustAngle(-5f) })
        angles.addView(button("↷ 5°") { adjustAngle(5f) })
        root.addView(angles)
        root.addView(label("Ajuste o comprimento"))
        val lengths = LinearLayout(this).apply { gravity = Gravity.CENTER }
        lengths.addView(button("−") { adjustLength(-40) })
        lengths.addView(button("+") { adjustLength(40) })
        root.addView(lengths)
        root.addView(button("ATIVAR MIRA FLUTUANTE") { startAim() }, LinearLayout.LayoutParams(-1, 56).apply { topMargin = 24 })
        root.addView(button("DESATIVAR MIRA") { stopService(Intent(this@MainActivity, AimOverlayService::class.java)) }, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 10 })
        val note = TextView(this).apply {
            text = "A mira é um guia visual manual. Ela não reconhece automaticamente as bolas nem calcula jogadas. A linha é transparente e não captura toques do jogo."
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(0, 18, 0, 8)
    }

    private fun button(value: String, action: () -> Unit) = Button(this).apply {
        text = value; isAllCaps = false; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(0, 52, 1f).apply { setMargins(5, 4, 5, 4) }
    }

    private fun adjustAngle(delta: Float) {
        val next = (prefs.getFloat("angle", 0f) + delta).let { ((it + 360f) % 360f) }
        prefs.edit().putFloat("angle", next).apply()
        sendUpdate()
    }

    private fun adjustLength(delta: Int) {
        val next = (prefs.getInt("length", 420) + delta).coerceIn(100, 1000)
        prefs.edit().putInt("length", next).apply()
        sendUpdate()
    }

    private fun sendUpdate() { sendBroadcast(Intent(AimOverlayService.ACTION_UPDATE).setPackage(packageName)) }

    private fun startAim() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, AimOverlayService::class.java))
    }
}
